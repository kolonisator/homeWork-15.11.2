import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
      Scanner sum = new Scanner(System.in);
       double sum1 = sum.nextDouble();
        System.out.println("Общая сумма покупок: " + sum1);
        double sum2 = sum.nextDouble();
        System.out.println("Сумма которую дал покупатель " + sum2);
        System.out.println("Сдача " + ((int)(sum2 - sum1)) + " рублей " + ((sum2 - sum1)-((int)(sum2 - sum1)))  + " копеек ");
    }
}